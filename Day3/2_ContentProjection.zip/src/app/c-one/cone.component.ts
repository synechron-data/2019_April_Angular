import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-one',
    templateUrl: 'cone.component.html'
})

export class COneComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}