import { NgModule } from "@angular/core";
import { CTwoComponent } from "./ctwo.component";

@NgModule({
    declarations: [CTwoComponent],
    exports: [CTwoComponent]
})
export class MTwoModule {
}