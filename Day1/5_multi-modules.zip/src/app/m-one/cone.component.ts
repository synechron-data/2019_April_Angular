import { Component } from "@angular/core";

@Component({
    selector: 'c-one',
    template: `
        <div class="container">    
            <h1 class="text-info">Hello from Component One - Module One!</h1>
        </div>
    `
})
export class COneComponent { }