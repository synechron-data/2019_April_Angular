import { NgModule } from "@angular/core";
import { COneComponent } from "./cone.component";

@NgModule({
    declarations: [COneComponent],
    exports: [COneComponent]
})
export class MOneModule {
}