import { Component } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Assignment</h1>
            </div>

        </div>
    `
})

export class RootComponent {
    constructor() {
    }
}